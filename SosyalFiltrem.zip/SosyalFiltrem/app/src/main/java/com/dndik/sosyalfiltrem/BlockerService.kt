package com.dndik.sosyalfiltrem

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Erişilebilirlik Servisi — uygulamanın kalbi.
 *
 * Instagram ve YouTube'u izler; Reels/Shorts tespit edince:
 *  1. İzleme sayacını artırır.
 *  2. Oturum süresini takip eder.
 *  3. Günlük limit dolunca OverlayActivity'yi başlatıp geri gider.
 *
 * NOT: Uygulama güncellemeleriyle bazı viewId'ler değişebilir.
 *      Değişirse aşağıdaki COMPANION sabitlerini güncelleyin.
 */
class BlockerService : AccessibilityService() {

    private lateinit var prefs: PrefsManager

    // Oturum takibi
    private var isInContent    = false
    private var sessionStart   = 0L
    private var lastScrollMs   = 0L          // debounce için
    private var lastPkg        = ""

    companion object {
        const val IG_PKG  = "com.instagram.android"
        const val YT_PKG  = "com.google.android.youtube"

        // Instagram Reels — ViewPager/RecyclerView resource id'si
        const val IG_REELS_ID = "com.instagram.android:id/clips_viewer_pager"
        // YouTube Shorts — Shorts player container
        const val YT_SHORTS_ID = "com.google.android.youtube:id/shorts_player_view"

        // Scroll olayları arasındaki minimum süre (ms) — tek swipe = tek Reel
        const val SCROLL_DEBOUNCE_MS = 600L
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = PrefsManager(applicationContext)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        prefs.resetIfNewDay()
        if (!prefs.isEnabled) return

        val pkg = event.packageName?.toString() ?: return

        // Kullanıcı farklı uygulamaya geçtiyse oturumu bitir
        if (pkg != lastPkg) {
            if (isInContent) endSession()
            lastPkg = pkg
        }

        when (pkg) {
            IG_PKG -> handleInstagram(event)
            YT_PKG -> handleYouTube(event)
        }
    }

    // ─── Instagram ───────────────────────────────────────────────────────────

    private fun handleInstagram(event: AccessibilityEvent) {
        val root = rootInActiveWindow ?: return
        val inReels = isInstagramReels(root)
        root.recycle()

        when {
            inReels && prefs.isLimitReached() -> {
                showBlock(); return
            }
            inReels && !isInContent -> {
                // Reels ekranına ilk giriş
                isInContent  = true
                sessionStart = System.currentTimeMillis()
                prefs.incrementCount()
                if (prefs.isLimitReached()) showBlock()
            }
            inReels && event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                // Yeni bir Reel'e kaydırdı (debounce ile)
                val now = System.currentTimeMillis()
                if (now - lastScrollMs > SCROLL_DEBOUNCE_MS) {
                    lastScrollMs = now
                    prefs.incrementCount()
                    if (prefs.isLimitReached()) showBlock()
                }
            }
            !inReels && isInContent -> endSession()
        }
    }

    /**
     * Instagram'da Reels ekranında olup olmadığını belirler.
     *
     * Önce viewId ile arar (güvenilir); bulamazsa metin+video heuristiği kullanır.
     */
    private fun isInstagramReels(root: AccessibilityNodeInfo): Boolean {
        // Yöntem 1 — viewId (hızlı ve kesin)
        val byId = root.findAccessibilityNodeInfosByViewId(IG_REELS_ID)
        if (byId.isNotEmpty()) {
            byId.forEach { it.recycle() }
            return true
        }

        // Yöntem 2 — metin tespiti: "Reels" yazısı görünüyor mu?
        val reelsNodes = root.findAccessibilityNodeInfosByText("Reels")
        val hasText = reelsNodes.isNotEmpty()
        reelsNodes.forEach { it.recycle() }
        if (!hasText) return false

        // Metin varken de tam ekran video var mı kontrol et
        // (yoksa sadece navigasyon ikonunda "Reels" yazısı görünüyordur)
        return hasNodeWithClass(root, "android.view.SurfaceView") ||
               hasNodeWithClass(root, "android.view.TextureView")
    }

    // ─── YouTube ─────────────────────────────────────────────────────────────

    private fun handleYouTube(event: AccessibilityEvent) {
        val root = rootInActiveWindow ?: return
        val inShorts = isYouTubeShorts(root)
        root.recycle()

        when {
            inShorts && prefs.isLimitReached() -> {
                showBlock(); return
            }
            inShorts && !isInContent -> {
                isInContent  = true
                sessionStart = System.currentTimeMillis()
                prefs.incrementCount()
                if (prefs.isLimitReached()) showBlock()
            }
            inShorts && event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                val now = System.currentTimeMillis()
                if (now - lastScrollMs > SCROLL_DEBOUNCE_MS) {
                    lastScrollMs = now
                    prefs.incrementCount()
                    if (prefs.isLimitReached()) showBlock()
                }
            }
            !inShorts && isInContent -> endSession()
        }
    }

    /**
     * YouTube'da Shorts playerında olup olmadığını belirler.
     */
    private fun isYouTubeShorts(root: AccessibilityNodeInfo): Boolean {
        // Yöntem 1 — viewId
        val byId = root.findAccessibilityNodeInfosByViewId(YT_SHORTS_ID)
        if (byId.isNotEmpty()) {
            byId.forEach { it.recycle() }
            return true
        }

        // Yöntem 2 — pencere başlığı (TYPE_WINDOW_STATE_CHANGED eventlerinde dolu gelir)
        val winTitle = root.text?.toString() ?: ""
        if (winTitle.contains("Shorts", ignoreCase = true)) return true

        // Yöntem 3 — "Shorts" etiketi görünüyor + dikey tam ekran video
        val shortNodes = root.findAccessibilityNodeInfosByText("Shorts")
        val hasLabel   = shortNodes.isNotEmpty()
        shortNodes.forEach { it.recycle() }

        if (!hasLabel) return false
        return hasNodeWithClass(root, "android.view.SurfaceView") ||
               hasNodeWithClass(root, "android.view.TextureView")
    }

    // ─── Yardımcılar ─────────────────────────────────────────────────────────

    /** Erişilebilirlik ağacında belirli sınıf adına sahip ilk düğümü arar */
    private fun hasNodeWithClass(node: AccessibilityNodeInfo, cls: String): Boolean {
        if (node.className?.toString() == cls) return true
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = hasNodeWithClass(child, cls)
            child.recycle()
            if (found) return true
        }
        return false
    }

    /** İçerik ekranından çıkıldı — oturum süresini kaydet */
    private fun endSession() {
        if (!isInContent) return
        isInContent = false
        val elapsed = (System.currentTimeMillis() - sessionStart) / 1000
        if (elapsed > 0) prefs.addSeconds(elapsed)
    }

    /** Limiti göster: geri git + OverlayActivity aç */
    private fun showBlock() {
        endSession()
        performGlobalAction(GLOBAL_ACTION_BACK)
        applicationContext.startActivity(
            Intent(applicationContext, OverlayActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
        )
    }

    override fun onInterrupt() { endSession() }

    override fun onDestroy() {
        super.onDestroy()
        endSession()
    }
}
