package com.dndik.sosyalfiltrem

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Cihaz açıldığında veya gece yarısı alarm geldiğinde sayaçları sıfırlar */
class DailyResetReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        PrefsManager(context).resetIfNewDay()
    }
}
