package com.dndik.sosyalfiltrem

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.dndik.sosyalfiltrem.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsManager(this)
        prefs.resetIfNewDay()
        setupButtons()
    }

    override fun onResume() {
        super.onResume()
        // Her açılışta güncel durumu yansıt
        binding.etMaxCount.setText(prefs.maxCount.toString())
        binding.etMaxMinutes.setText(prefs.maxMinutes.toString())
        updateToggle()
        updateStats()
    }

    private fun setupButtons() {

        // Erişilebilirlik ayarlarını aç
        binding.btnOpenAccessibility.setOnClickListener {
            Toast.makeText(this,
                "Listede 'SosyalFiltrem'i bulup aktifleştirin",
                Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // Toggle — servisi etkinleştir / devre dışı bırak
        binding.switchEnable.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked && !accessibilityGranted()) {
                binding.switchEnable.isChecked = false
                Toast.makeText(this,
                    "Önce Erişilebilirlik izni verin",
                    Toast.LENGTH_SHORT).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@setOnCheckedChangeListener
            }
            prefs.isEnabled = isChecked
            val msg = if (isChecked) "Engelleyici aktif ✅" else "Engelleyici kapalı"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }

        // Ayarları kaydet
        binding.btnSave.setOnClickListener {
            val count = binding.etMaxCount.text.toString().toIntOrNull()
            val mins  = binding.etMaxMinutes.text.toString().toIntOrNull()
            if (count == null || count < 1 || count > 999) {
                binding.etMaxCount.error = "1–999 arası girin"
                return@setOnClickListener
            }
            if (mins == null || mins < 1 || mins > 1440) {
                binding.etMaxMinutes.error = "1–1440 arası girin"
                return@setOnClickListener
            }
            prefs.maxCount   = count
            prefs.maxMinutes = mins
            Toast.makeText(this, "Ayarlar kaydedildi ✓", Toast.LENGTH_SHORT).show()
            updateStats()
        }

        // Bugünkü sayaçları sıfırla
        binding.btnReset.setOnClickListener {
            prefs.manualReset()
            updateStats()
            Toast.makeText(this, "Bugünkü veriler sıfırlandı", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateToggle() {
        val granted = accessibilityGranted()
        binding.tvAccessStatus.text = if (granted)
            "✅ Erişilebilirlik izni verildi"
        else
            "⚠️ Erişilebilirlik izni gerekli — butona bas"

        binding.switchEnable.isChecked = prefs.isEnabled && granted
    }

    private fun updateStats() {
        binding.tvStats.text = prefs.statsSummary()
    }

    private fun accessibilityGranted(): Boolean {
        val service = "${packageName}/${BlockerService::class.java.name}"
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        return enabled.contains(service)
    }
}
