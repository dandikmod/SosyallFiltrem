package com.dndik.sosyalfiltrem

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.dndik.sosyalfiltrem.databinding.ActivityOverlayBinding

/**
 * Günlük limit dolunca gösterilen tam ekran engelleme ekranı.
 * Kullanıcı geri tuşuna veya ana ekran butonuna basarak çıkabilir —
 * fakat Instagram/YouTube'a geri dönemez (servis hemen tekrar kapatır).
 */
class OverlayActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOverlayBinding
    private lateinit var prefs: PrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOverlayBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PrefsManager(this)
        prefs.resetIfNewDay()

        // İstatistikleri doldur
        val count    = prefs.dailyCount
        val usedMins = prefs.dailySeconds / 60
        val maxCount = prefs.maxCount
        val maxMins  = prefs.maxMinutes

        binding.tvTitle.text = "Günlük Limit Doldu 🔒"
        binding.tvMessage.text = buildString {
            appendLine("Bugün $count Reels/Shorts izledin.")
            appendLine("Toplam süre: ${usedMins} dakika")
            appendLine()
            appendLine("Belirlediğin limit: $maxCount Reels · ${maxMins} dakika")
            appendLine()
            appendLine("Gece yarısında sıfırlanacak ✨")
            appendLine("Şimdi telefonu kaldır, biraz hareket et! 💪")
        }

        // Ana ekrana git
        binding.btnHome.setOnClickListener {
            goHome()
        }

        // Ayarlara git (limiti değiştirmek için)
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        )
        finish()
    }

    // Geri tuşu: kullanıcıyı ana ekrana yönlendir, uygulamaya döndürme
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        goHome()
    }
}
