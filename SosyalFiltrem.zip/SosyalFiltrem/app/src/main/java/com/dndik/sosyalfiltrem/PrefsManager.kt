package com.dndik.sosyalfiltrem

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.*

/**
 * Tüm ayarları ve günlük istatistikleri SharedPreferences'ta tutar.
 * Gün değiştiğinde sayaçları otomatik sıfırlar.
 */
class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("sosyalfiltrem", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_ENABLED       = "enabled"
        private const val KEY_MAX_COUNT     = "max_count"
        private const val KEY_MAX_MINUTES   = "max_minutes"
        private const val KEY_DAILY_COUNT   = "daily_count"
        private const val KEY_DAILY_SECONDS = "daily_seconds"
        private const val KEY_LAST_DATE     = "last_date"

        const val DEFAULT_MAX_COUNT   = 20   // maksimum Reels/Shorts adedi
        const val DEFAULT_MAX_MINUTES = 20   // maksimum dakika
    }

    private fun todayStr(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    /** Eğer gün değiştiyse sayaçları sıfırla */
    fun resetIfNewDay() {
        if (prefs.getString(KEY_LAST_DATE, "") != todayStr()) {
            prefs.edit()
                .putInt(KEY_DAILY_COUNT, 0)
                .putLong(KEY_DAILY_SECONDS, 0L)
                .putString(KEY_LAST_DATE, todayStr())
                .apply()
        }
    }

    // ── Ayarlar ──────────────────────────────────────────────

    var isEnabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, false)
        set(v) = prefs.edit().putBoolean(KEY_ENABLED, v).apply()

    var maxCount: Int
        get() = prefs.getInt(KEY_MAX_COUNT, DEFAULT_MAX_COUNT)
        set(v) = prefs.edit().putInt(KEY_MAX_COUNT, v).apply()

    var maxMinutes: Int
        get() = prefs.getInt(KEY_MAX_MINUTES, DEFAULT_MAX_MINUTES)
        set(v) = prefs.edit().putInt(KEY_MAX_MINUTES, v).apply()

    // ── Günlük sayaçlar ──────────────────────────────────────

    var dailyCount: Int
        get() { resetIfNewDay(); return prefs.getInt(KEY_DAILY_COUNT, 0) }
        set(v) = prefs.edit().putInt(KEY_DAILY_COUNT, v).apply()

    var dailySeconds: Long
        get() { resetIfNewDay(); return prefs.getLong(KEY_DAILY_SECONDS, 0L) }
        set(v) = prefs.edit().putLong(KEY_DAILY_SECONDS, v).apply()

    fun incrementCount() { dailyCount = dailyCount + 1 }

    fun addSeconds(sec: Long) { dailySeconds = dailySeconds + sec }

    fun manualReset() {
        prefs.edit()
            .putInt(KEY_DAILY_COUNT, 0)
            .putLong(KEY_DAILY_SECONDS, 0L)
            .putString(KEY_LAST_DATE, todayStr())
            .apply()
    }

    // ── Limit kontrolü ───────────────────────────────────────

    fun isLimitReached(): Boolean {
        if (!isEnabled) return false
        return dailyCount >= maxCount || dailySeconds >= maxMinutes * 60L
    }

    /** Kullanıcıya gösterilecek kalan hak özeti */
    fun statsSummary(): String {
        val usedMins = dailySeconds / 60
        val usedSecs = dailySeconds % 60
        val remCount = maxOf(0, maxCount - dailyCount)
        val remMins  = maxOf(0, maxMinutes - usedMins.toInt())
        return buildString {
            appendLine("📺  Bugün izlenen: ${dailyCount} / ${maxCount} Reels")
            appendLine("⏱  Toplam süre: ${usedMins}dk ${usedSecs}sn / ${maxMinutes}dk")
            appendLine()
            appendLine("✅  Kalan: $remCount Reels · ${remMins}dk")
            if (isLimitReached()) {
                appendLine()
                appendLine("🔒  Bugünlük limit doldu. Yarın sıfırlanacak.")
            }
        }
    }
}
